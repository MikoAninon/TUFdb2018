<?php 
    $conn = mysqli_connect ("localhost","root","","tufdb");

    if (!$conn){
        echo "Connection unsuccesful!"; 
    }


?>